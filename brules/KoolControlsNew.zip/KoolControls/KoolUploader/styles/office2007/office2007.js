/*
 * This defined function will be called to init the style
 */
function office2007KULInit(id)
{
	var _div = document.getElementById(id);
	var _tbody = _div.firstChild.firstChild;
	var _first_td = _tbody.firstChild.firstChild;
	var _last_td = _tbody.lastChild.firstChild;
	_first_td.style.height = (parseInt(_div.style.height) - parseInt(_last_td.style.height) ) + "px";
}